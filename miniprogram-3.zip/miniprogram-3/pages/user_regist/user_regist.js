var util = require('../../utils/util.js'); //常用方法
var app = getApp();
var car_userName = ''
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  onLoad: function(options) {
    let that = this
    wx.request({
      url: 'https://xiayuhui.top:8443/user/findUserSt',
      data:{
        userId:wx.getStorageSync('openid')
      },
      success(res) {
        console.log(res)
        if (res.data) {
          wx.switchTab({
            url: '../index/index',
          })
        } else {
          wx.getUserInfo({
            success: function(res) {
              wx.setStorageSync('nickName', JSON.parse(res.rawData).nickName)
              that.setData({
                userInfo: {
                  avatar: JSON.parse(res.rawData).avatarUrl,
                  nickname: JSON.parse(res.rawData).nickName
                }
              })
            }
          })
          wx.login({
            success(res) {
              wx.request({
                url: `https://api.weixin.qq.com/sns/jscode2session?appid=wxc5b98cc22be4e8a4&secret=a6ef39f1e287e54e91b6de4602f2bcfb&js_code=${res.code}&grant_type=authorization_code`,
                success(res) {
                  wx.setStorageSync('openid', res.data.openid)
                }
              })
            }
          })
        }
      }
    })
  },
  formSubmit: function(e) {
    let realname = e.detail.value.realname
    let phone = e.detail.value.phone
    let place = e.detail.value.place
    if (!(/^1[3456789]\d{9}$/.test(phone))) {
      wx.showToast({
        title: '手机号格式错误',
      })
    } else {
      console.log(place)
      wx.request({
        url: 'https://xiayuhui.top:8443/user/insertUser',
        data: {
          username: wx.getStorageSync('openid'),
          userRealname: realname,
          userPhone: phone,
          userPlace: place
        },
        success(res) {
          if(res.data=='success'){
            wx.switchTab({
              url: '../index/index',
            })
          }
        }
      })
    }
  },


  onReady: function() {
    var that = this;
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})