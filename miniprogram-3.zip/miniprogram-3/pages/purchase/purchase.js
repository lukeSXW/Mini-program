// pages/purchase/purchase.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    per_info:'',
    goods:[],
    shoppingPrice:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    console.log(options)
    if(options.goodsId){
      wx.request({
        url: 'https://xiayuhui.top:8443/search/id',
        data:{
          goodsId:options.goodsId
        },
        success(res){
          let good = {}
          good.goodsPic = res.data.goodsPic
          good.goodsName=res.data.goodsName
          good.goodsPrice=res.data.goodsPrice
          good.amount = options.count
          let arr = that.data.goods
          arr.push(good)
          that.setData({
            goods:arr,
            shoppingPrice:res.data.goodsPrice*options.count
          })
        }
      })
    }else{
     wx.request({
      url: 'https://xiayuhui.top:8443/shopping/findAll',
      data:{
        user:wx.getStorageSync('openid')
      },
      success(res){
        console.log(res)
        that.setData({
          goods:res.data.shopping,
          shoppingPrice:res.data.shoppingPrice
        })
      }
    })
    }
    
    wx.request({
      url: 'https://xiayuhui.top:8443/user/findUser',
      data:{
        userId:wx.getStorageSync('openid')
      },
      success(res){
        that.setData({
          per_info:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})