// pages/shopping_car/shopping_car.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:'-1',
    edit:'编辑',
    goods:[],
    show:'hidden',
    shoppingPrice:0,
    All:'white'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/findAll',
      data:{
        user:wx.getStorageSync('openid')
      },
      success(res){
        console.log(res)
        let goods = res.data.shopping
        goods.forEach(value=>{
          value.check = 'white'
        })
        that.setData({
          goods,
          shoppingPrice:res.data.shoppingPrice
        })
      }
    })
  },

  delete(){
    let arr = this.data.goods
    let shoppingPrice = this.data.shoppingPrice
    let goods = []
    let goodsId = []
    arr.forEach(value=>{
      if(value.check == 'white')
        goods.push(value)
        else{
          goodsId.push(value.goodsId) 
          shoppingPrice -= value.goodsPrice
        }
    })
    console.log(goodsId.join(','))
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/reduceSome',
      data:{
        user:wx.getStorageSync('openid'),
        goodsId:goodsId.join(','),
      },
      success(res){
        console.log("删除成功")
      }
    })
    this.setData({
      goods,
      shoppingPrice
    })
  },

  purchase(){
    wx.navigateTo({
      url: '../purchase/purchase',
    })
  },


  selectAll(){
    console.log(1)
    let All = this.data.All
    let arr = this.data.goods
    arr.forEach(value=>{
      value.check = value.check=='white'?'red':'white'
    })
    this.setData({
      goods:arr,
      All:All == 'white'?'red':'white'
    })
  },

  add(e){
    let that = this
    let arr = this.data.goods
    let id = e.currentTarget.id
    arr.forEach(value=>{
      if(value.goodsId == id){
        value.amount++;
      }
    })
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/add',
      data:{
        goodsId:id,
        user:wx.getStorageSync('openid'),
        amount:1
      },
      success(res){
        console.log('修改成功')
      }
    })
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/findAll',
      data:{
        user:wx.getStorageSync('openid')
      },
      success(res){
        console.log(res)
        let goods = res.data.shopping
        goods.forEach(value=>{
          value.check = 'white'
        })
        that.setData({
          shoppingPrice:res.data.shoppingPrice
        })
      }
    })
    this.setData({
      goods:arr
    })
  },
  reduce(e){
    let that = this
    let arr = this.data.goods
    let id = e.currentTarget.id
    arr.forEach((value,index)=>{
      if(value.goodsId == id){
        value.amount--;
        if(value.amount == 0){
          arr.splice(index,1)
        }
      }
    })
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/findAll',
      data:{
        user:wx.getStorageSync('openid')
      },
      success(res){
        console.log(res)
        let goods = res.data.shopping
        goods.forEach(value=>{
          value.check = 'white'
        })
        that.setData({
          shoppingPrice:res.data.shoppingPrice
        })
      }
    })
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/reduce',
      data:{
        goodsId:id,
        user:wx.getStorageSync('openid'),
        amount:1
      },
      success(res){
        console.log('修改成功')
      }
    })
    this.setData({
      goods:arr
    })
  },
  check(e){
    let arr = this.data.goods
    let id = e.currentTarget.id
    arr.forEach(value=>{
      if(value.goodsId == id)
        value.check = value.check=='white'?'red':'white'
    })
    this.setData({
      goods:arr
    })
  },
  edit(){
    let index = this.data.index
    let edit = this.data.edit
    let show = this.data.show
    edit= edit=='编辑'?'完成':'编辑'
    index = index==-1?1:-1
    show = show=='hidden'? 'visible':'hidden'
    this.setData({
      index,
      edit,
      show
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let that = this
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/findAll',
      data:{
        user:wx.getStorageSync('openid')
      },
      success(res){
        console.log(res)
        let goods = res.data.shopping
        goods.forEach(value=>{
          value.check = 'white'
        })
        that.setData({
          goods,
          shoppingPrice:res.data.shoppingPrice
        })
      }
    })
  },

  clear(){
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/delete',
      data:{
        user:wx.getStorageSync('openid')
      },
      success(res){
        console.log('清空成功')
      }
    })
    this.setData({
      goods:[]
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },




  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})