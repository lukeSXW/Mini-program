//index.js
//获取应用实例
const app = getApp()
let QQMapWX = require('../../libs/qqmap-wx-jssdk.js');
let qqmapsdk;
let key = 'F3QBZ-WD7CS-KLBOL-6IZ42-RMFLZ-J7B5R'
const referer = '出行助手'; //调用插件的app的名称

Page({
  data: {
    goods_arr: [],
    user_name: '',
    user_avatarUrl: '',
    user_position: '',
    food_cate: [{
        id: 1,
        img_src: '/resource/images/fruit.png',
        food_name: '水果馆'
      },
      {
        id: 2,
        img_src: '/resource/images/vegtable.png',
        food_name: '蔬菜馆'
      },
      {
        id: 3,
        img_src: '/resource/images/cookie.jpg',
        food_name: '休闲零食馆'
      },
      {
        id: 4,
        img_src: '/resource/images/seasoning.jpg',
        food_name: '粮油调味馆'
      },
      {
        id: 5,
        img_src: '/resource/images/furniture.jpg',
        food_name: '家居清理馆'
      },
      {
        id: 6,
        img_src: '/resource/images/clothes.jpg',
        food_name: '服饰穿戴馆'
      },
      {
        id: 7,
        img_src: '/resource/images/meat.png',
        food_name: '肉肉馆'
      },
      {
        id: 8,
        img_src: '/resource/images/fish.png',
        food_name: '水产馆'
      },
      {
        id: 9,
        img_src: '/resource/images/egg.png',
        food_name: '豆腐馆'
      }
    ]
  },

  choose_cate(e) {
    let id = e.currentTarget.id
    wx.setStorageSync('cate_id', id)
    wx.switchTab({
      url: '../category/category',
    })
  },

  


  search_goods() {
    wx.navigateTo({
      url: '../search_goods/search_goods',
    })
  },

  


  add2car(e){
    let goodsId = e.target.id
    console.log(goodsId,wx.getStorageSync('openid'))
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/add',
      data:{
        goodsId,
        user:wx.getStorageSync('openid'),
        amount:1
      },
      success(res){
        wx.showToast({
          title: '加入购物车成功',
        })
      }
    })
  },

  show_detail(e){
    let id = e.currentTarget.id
    wx.navigateTo({
      url: '../goods_detail/goods_detail?id='+id,
    })
  },

  onLoad: function() {
    wx.setStorageSync('cate_id', 1)
    let that = this
    qqmapsdk = new QQMapWX({
      key: key
    });
    wx.getUserInfo({
      success(res) {
        that.setData({
          user_name: res.userInfo.nickName,
          user_avatarUrl: res.userInfo.avatarUrl,
        })
      }
    })
    wx.getLocation({
      success: function(res) {
        qqmapsdk.reverseGeocoder({
          location: {
            latitude: res.latitude,
            longitude: res.longitude
          },
          success(res) {
            that.setData({
              user_position: res.result.formatted_addresses.recommend
            })
          }
        })
      },
    })
    wx.request({
      url: 'https://xiayuhui.top:8443/search/suiji',
      success(res) {
        res.data.forEach(value => {
          if (value.goodsPic[0] != '/')
            value.goodsPic = null
          else {
            value.goodsPic = value.goodsPic.split(',')[0]
          }
        })
        that.setData({
          goods_arr: res.data
        })
      }
    })
  }
})