var app = getApp()
Page({
  data: {
    city: '',
    realtime: {},
    future: []
  },

  onLoad: function () {
    this.getla_long()
  },

  //获取目标经纬度
  getla_long: function () {
    var that = this
    wx.getLocation({
      success: function (res) {
        that.get_city(res)
      },
    })
  },

  //获取目标城市
  get_city: function (res) {
    var that = this
    wx.request({
      url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude + '&key=ENDBZ-7XUYX-LHO4P-TCH4E-4RKEH-XVFHB',
      success(res) {
        that.get_weather(res)
      }
    })
  },

  //获取天气信息
  get_weather: function (res) {
    var that = this
    var city = res.data.result.address_component.city.replace('市', '')
    wx.request({
      url: 'https://apis.juhe.cn/simpleWeather/query?' + 'city=' + city + '&key=339731a4563e5989eaef0c5af97c5333',
      success(res) {

        that.setData({
          city: res.data.result.city,
          realtime: res.data.result.realtime,
          future: res.data.result.future,
        })
        console.log(that.data.future[0])
      }
    })
  }
})