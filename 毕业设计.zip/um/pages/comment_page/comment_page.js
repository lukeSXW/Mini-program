Page({

  /**
   * 页面的初始数据
   */
  data: {
    detail: {},
    scale: '0.01',
    poster: '',
    left: '10%',
    loading: false,
    photo_show: true,
    userInfo: {},
    inputStatus: 0,
    detail_img: [],
    comments: [
      ''
    ]
  },
  /**
   * 生命周期函数--监听页面加载
   */

  // 显示输入框函数
  showInput: function() {
    let length = this.data.length
    length = length == '25%' ? "120%" : "25%"
    this.setData({
      length: length
    })
  },
  onLoad: function(options) {
    let that = this
    if (options.girl == 'true') {
      that.setData({
        photo_show: false,
      })
    }

    wx.request({
      url: `https://www.htmlstudio.top/home/detail_${options.id}`,
      success(res) {
        console.log(res)
        that.setData({
          detail: res.data.detail,
          poster: res.data.detail.content_img,
          comments: res.data.detail.comments
        })
      }
    })
  },

  // 提交评论
  post_msg: function(e) {
    let that = this
    let comment = e.detail.value.comment
    let id = this.data.detail.id
    let cate = this.data.detail.cate
    console.log(comment)
    if (comment) {
      wx.request({
        url: 'https://www.htmlstudio.top/comments',
        data: {
          id: id,
          comment: comment,
          cate: cate
        },
        success(res) {
          console.log(res)
          that.setData({
            comments: res.data
          })
        }
      })
      that.setData({
        length: "120%"
      })
    }else{
      wx.showToast({
        title: '评论不能为空哦',
      })
    }
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})