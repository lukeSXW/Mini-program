var util = require('../../utils/util.js'); //常用方法
var app = getApp();
var car_userName = ''
wx.getUserInfo({
  success(res) {
    car_userName = JSON.parse(res.rawData).nickName
  }
})
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getSetting({
      success(res){
        let userInfo = res.authSetting["scope.userInfo"]
        if(!userInfo){
          wx.showModal({
            title:"您还未授权",
            icon:'none',
            showCancel:false,
            confirmText:'去授权',
            confirmColor:"red",
            success(res){
              if(res.confirm){
                wx.switchTab({
                  url: '../per_info/per_info',
                })
              }
            }
          })
        }
      },
      complete: (res) => {
        
      },
    })
    var app = getApp();
    var that = this;
    wx.login({
      success(res) {
        wx.request({
          url: `https://api.weixin.qq.com/sns/jscode2session?appid=wxc5b98cc22be4e8a4&secret=a6ef39f1e287e54e91b6de4602f2bcfb&js_code=${res.code}&grant_type=authorization_code`,
          success(res) {
            wx.setStorageSync('openid', res.data.openid)
            console.log(wx.getStorageSync('openid'))
          }
        })
      }
    })
    wx.getUserInfo({
      success: function (res) {
        console.log(res)
        var userInfo = res.userInfo;
        wx.setStorageSync('nickname', userInfo.nickName)
        wx.setStorageSync('avatar', userInfo.avatarUrl)
        that.setData({
          userInfo: {
            avatar: userInfo.avatarUrl,
            nickname: userInfo.nickName,
          }
        })
      }
    })
  },
  formSubmit: function (e) {
    let that = this;
    let per_info = e.detail.value
    per_info.nickName = wx.getStorageSync('nickname')
    per_info.openid = wx.getStorageSync('openid')
    per_info.avatar = wx.getStorageSync('avatar')
    if (per_info.nickName && per_info.sex && per_info.password) {
      wx.request({
        url: 'https://www.htmlstudio.top/regist',
        method: 'get',
        data: per_info,
        success(res) {
          console.log(res)
          if (res.data.status == '注册成功') {
            wx.setStorageSync('login_status', true)
            wx.showToast({
              title: res.data.status,
            })
            wx.switchTab({
              url: '../per_info/per_info',
              success() {
                wx.setStorageSync('uid', res.data.id)
              }
            })
          } else if (res.data.status == '用户已存在') {
            wx.setStorageSync('login_status', true)
            wx.showModal({
              title: '登录成功',
              showCancel: false,
              confirmText: "去使用",
              success(res) {
                if (res.confirm)
                  wx.switchTab({
                    url: '../per_info/per_info',
                    success() {
                      wx.setStorageSync('uid', res.data.id)
                    }
                  })
              }
            })

          } else {
            wx.showModal({
              title: '密码错误！',
              showCancel: false
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: '个人信息不完整',
        image: '../../resource/images/error.png'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})