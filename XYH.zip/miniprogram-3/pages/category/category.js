// pages/category/category.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cate_arr:[],
    cate_goods:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    wx.request({
      url: 'https://xiayuhui.top:8443/search/ty',
      success(res){
        that.setData({
          cate_arr : res.data
        })
        that.choose_cate({"target":{"id":wx.getStorageSync('cate_id')}})
      }
    })
    
  },

  choose_cate(event){
    let id = event.target.id
    let arr = this.data.cate_arr
    this.cate_detail(id)
    arr.forEach(value=>{
      if(value.typeId == id){
        value.color='black'
        value.back = 'white'
      }else{
        value.color = 'grey'
        value.back = '#e9ecf1'
      }
    })
    this.setData({
      cate_arr:arr
    })
  },

  cate_detail(id){
    let that = this
    console.log(id)
    wx.request({
      url: 'https://xiayuhui.top:8443/search/type',
      data:{
        type:id
      },
      success(res){
        that.setData({
          cate_goods:res.data
        })
        console.log(res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // let that = this
    // wx.request({
    //   url: 'https://xiayuhui.top:8443/search/ty',
    //   success(res) {
    //     that.setData({
    //       cate_arr: res.data
    //     })
    //     that.choose_cate({ "target": { "id": wx.getStorageSync('cate_id') } })
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})