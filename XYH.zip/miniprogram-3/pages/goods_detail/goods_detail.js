// pages/goods_detail/goods_detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tips:[
      {
        title:'1.在线下单',
        content:'每天可购买商品时间:00:00-23:00'
      },
      {
        title:'2.物流配送',
        content:'每天16:00之前，物流会将您昨日购买的商品，配送到您购买时选择的自提门店'
      },
      {
        title:'3.门店自提',
        content:'每天16:00之后,(门店不同，到货时间会有差异),您需要到购买时选择的自提门店提货'
      },
      {
        title:'4.售后无忧',
        content:'如果您购买的商品有任何问题,请直接与购买的门店联系,门店将为您处理,让您售后无忧!'
      },
      {
        title:'6.XX优选全国热线',
        content:'r如果您找不到购物的自提门店,请致电XX优选帮帮忙热线！电话:XXXXXXXXXX'
      }
    ],
    detail:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    wx.request({
      url: 'https://xiayuhui.top:8443/search/id',
      data:{
        goodsId:3
      },
      success(res){
        console.log(res)
        that.setData({
          detail:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})