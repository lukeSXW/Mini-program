var app = getApp();
Page({
  data: {
    inputVal: '',
    list: []
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  bindKeyInput: function (e) {
    this.setData({
      inputVal: e.detail.value
    })
  },
  search: function (e) {
    var page = this;
    if (this.data.inputVal!= ''){
    wx.request({
      url: 'http://apis.juhe.cn/cook/query?key=' + app.AppKey + '&menu=' + page.data.inputVal,
      data: {},
      method: 'GET',
      success: function (res) {
        console.log(res.data);
        var list = res.data.result.data;
        page.setData({ list: list })
      }
    })
   
  }
    else{
      wx.showToast({
        title: '输入不能为空',
        icon: 'none',
        duration: 2500
      })
  }
},
      // fail: function (e) {
      //   wx.showModal({
      //     title: '提示',
      //     content: '请输入菜名',
      //     success: function (res) {
      //       if (res.confirm) {
      //         console.log('用户点击确定')
      //       } else if (res.cancel) {
      //         console.log('用户点击取消')
      //       }
      //     }
      //   })
      // },
      // complete: function (e) {
      //   wx.showModal({
      //     title: '提示',
      //     content: '请输入正确的菜名',
      //     success: function (res) {
      //       if (res.confirm) {
      //         console.log('用户点击确定')
      //       } else if (res.cancel) {
      //         console.log('用户点击取消')
      //       }
      //     }
      //   })
      // }
  
  
  navToDetail: function (e) {
    var id = e.currentTarget.id;
    wx.navigateTo({
      url: '/pages/detail/detail?id=' + id
    })
  }
})