//获取应用实例
var app = getApp()
var arr_name = ["菜式菜品", "菜系", "时令食材", "功效", "场景", "工艺口味", "菜肴", "主食", "西点", "汤羹饮品", "其他菜品", "人群", "疾病", "畜肉类", "禽蛋类", "水产类", "蔬菜类", "水果类", "乳制品", "日常", "节日", "节气", "基本工艺", "其他工艺", "基本口味", "多元口味", "水果味", "调味料"]
var arr_link = [10001, 10002, 10003, 10004, 10005, 10006, 10007, 10008, 10009, 10010, 10011, 10012, 10013, 10014, 10015, 10016, 10017, 10018, 10019, 10020, 10021, 10022, 10023, 10024, 10025, 10026, 10027, 10028]
var file = "pages/fendetail/fendetail"
Page({
  data: {
    items: [{
      id: "10001",
      src: "http://www.fj775177.com//pictures/month_1712/201712201159447582.jpg",
      text: arr_name[0]
    }, {
      id: "10002",
        src: "http://www.cflac.org.cn/wywzt/2012/zbwh/201201/W020120202392417183945.jpg",
      text: arr_name[1]
    }, {
      id: "10003",
        src: "https://04imgmini.eastday.com/mobile/20180906/d9a8f5f58fd80332113433654fd5fb83_wmk.jpeg",
      text: arr_name[2]
    }, {
      id: "10004",
        src: "https://ypimg1.youpu.cn/yp/201904/10/c8fa73c22188ef53d6d638286c35e6ea.png@640w_430h_1c_1e_1o",
      text: arr_name[3]
    }, {
      id: "10005",
        src: "http://pic2.52pk.com/files/171108/5613886_165935_1_lit.jpg",
      text: arr_name[4]
    }, {
      id: "10006",
        src: "https://img.yzcdn.cn/upload_files/2017/12/09/FvnBYIqPFuMPgFSlsA_-_5lkZrHI.jpg?imageView2/2/w/580/h/580/q/75/format/jpg",
      text: arr_name[5]
    }, {
      id: "10007",
        src: "http://5b0988e595225.cdn.sohucs.com/images/20190201/cacbd2183dbc4b4883c920c3cc5bd6c1.jpeg",
      text: arr_name[6]
    }, {
      id: "10008",
        src: "https://dxy.com/attachment/show/1187427",
      text: arr_name[7]
    }, {
      id: "10009",
        src: "https://pic2.zhimg.com/v2-7ebe67b0a8428d42df462235aeeb074a_b.jpg",
      text: arr_name[8]
    }, {
      id: "10010",
        src: "https://i8.meishichina.com/attachment/recipe/2016/02/17/20160217pzna7tuaxxfdaiyo.JPG?x-oss-process=style/p800",
      text: arr_name[9]
    }, {
      id: "10011",
        src: "http://www.canyin88.com/uploads/image/20150716/1437029474789256.jpg",
      text: arr_name[10]
    }, {
      id: "10012",
        src: "http://img2.3png.com/aab422821e0148e014930feefbebf3a603e2.png",
      text: arr_name[11]
    }, {
      id: "10013",
        src: "https://www.youth.gov.hk/html/www/en/images/banner/info-centre/health/diseasesprevent_v1.jpg",
      text: arr_name[12]
    }, {
      id: "10014",
        src: "http://img.gzxdf.com/uploads/gzxdf/allimg/190505/11-1Z505100T3X1.jpg",
      text: arr_name[13]
    }, {
      id: "10015",
        src: "https://qinbing.oss-cn-beijing.aliyuncs.com/2019/03/22/5c948b30c0a87.png",
      text: arr_name[14]
    }, {
      id: "10016",
        src: "http://file.55df.com/2017-09-03/e6fff5f3151a9d237c6091b363b90d69.jpeg",
      text: arr_name[15]
    }, {
      id: "10017",
        src: "http://i1.sinaimg.cn/book/2013/1025/U7769P112DT20131025134722.jpg",
      text: arr_name[16]
    }, {
      id: "10018",
        src: "http://photocdn.sohu.com/20150915/mp31924363_1442292444568_2.jpeg",
      text: arr_name[17]
    }, {
      id: "10019",
        src: "http://www.wiseste.com/uploads/allimg/131024/1-13102410351cG.jpg",
      text: arr_name[18]
    }, {
      id: "10020",
        src: "http://www.thmssy.com/uploads/allimg/190604/1-1Z60411340GY.jpg",
      text: arr_name[19]
    }, {
      id: "10021",
        src: "http://img.mp.itc.cn/upload/20170526/99c4585e84c34f4d91d1f1cf9700d272_th.jpg",
      text: arr_name[20]
    }, {
      id: "10022",
        src: "http://img0.dili360.com/ga/M02/34/B7/wKgBzFTIR6WAMbG4ACA-3WHx-rY353.tub.jpg@!rw9",
      text: arr_name[21]
    }, {
      id: "10023",
        src: "http://pic13.qiyeku.com/qiyeku_pic/2014/6/9/yindiao911/product/product_pic/image/2015_01_13/20150113084433982.jpg",
      text: arr_name[22]
    }, {
      id: "10024",
        src: "http://5b0988e595225.cdn.sohucs.com/images/20180226/04c671b6addb4d6eb0b0406f7fc9c209.jpeg",
      text: arr_name[23]
    }, {
      id: "10025",
        src: "https://tshop.r10s.com/e7a/e3c/87ab/f667/10ac/4e63/d41b/11fde98a750242ac110004.jpg",
      text: arr_name[24]
    }, {
      id: "10026",
        src: "http://www.qcbxwms.cn/upload_files/tk7788730.jpg",
      text: arr_name[25]
    }, {
      id: "10027",
        src: "https://as.chdev.tw/CH/images/channel_master/07888add-c979-478d-a961-8c4fa743b7af.jpg",
      text: arr_name[26]
    }, {
      id: "10028",
        src: "https://pic2.zhimg.com/v2-fada4889215d10c3389a32250727744c_1200x500.jpg",
      text: arr_name[27]
    }],
    url: file,
  },
  jumptodetail:function(e){
    console.log(e.currentTarget.id)
    console.log(e.currentTarget.dataset.listname)
    wx.navigateTo({
      url: '../../pages/fendetail/fendetail?listId=' + e.currentTarget.id + '&listName=' + e.currentTarget.dataset.listname,
    })
  }
})
