//获取应用实例
var app = getApp()
Page({
  data:{
    username:null,
    password:null
  },
  getMyInfo: function (e) {
    let info = e.detail.userInfo;
    this.setData({
      isLogin: true,
      src: info.avatarUrl,
      nickName: info.nickName,
      province: info.province
    })
    console.log(e.detail.userInfo)
  },
  sy:function(res){
   wx.navigateTo({
      url: '../../pages/index/index',
      success: function(res) {

      },
      fail: function(res) {

      },
      complete: function(res) {
        
      },
    })
  }

})
