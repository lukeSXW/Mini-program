var app = getApp()
Page({

  data:{
   list:[],   
   bgurl:{
     bcground_1: 'http://p1.pstatp.com/large/pgc-image/cc7ee2af379b49bf822f398fb592a866',
     bcground_2: 'http://m.360buyimg.com/pop/jfs/t23041/56/1498292538/39801/d8fa3070/5b61c881N7b175f0d.jpg',
     bcground_3: 'https://cp1.douguo.com/upload/caiku/1/4/7/yuan_1428c9fe36b3677c84fb54bb7dd5f107.jpeg',
     bcground_4:'http://image2.pearvideo.com/main/20180630/10903540-174046-0.png',
     bcground_5:'http://5b0988e595225.cdn.sohucs.com/images/20190127/fe35765b94bd4a12b42e73548b0c6a1a.jpeg',
     bcground_6: 'https://www.foodnext.net/dispPageBox/getFile/GetImg.aspx?FileLocation=%2FPJ-FOODNEXT%2FFiles%2F&FileName=photo-04764-i.jpg',
     bcground_7: 'https://i.zgjm.org/top/20190521/507-1.jpg',
     bcground_8: 'http://ali.xinshipu.cn/20120708/original/1341717262198.jpg',
     bcground_9: 'https://pic2.zhimg.com/v2-fada4889215d10c3389a32250727744c_1200x500.jpg',
   }
  },

  navToDetail:function(e){
    
    wx.navigateTo({
      url: '../../pages/fendetail2/fendetail2?cid=' + e.currentTarget.id,
    })
  },
  
  onLoad: function (options) {
    var id = options.listId
    console.log(id)
    var that = this
    wx.request({
      url: 'http://apis.juhe.cn/cook/category?key=' + app.AppKey +'&parentid='+id,
      method: 'GET',
      success: function (res) {
        
        var list = res.data.result[0].list;
        list[0]['album'] = that.data.bgurl.bcground_1
        list[1]['album'] = that.data.bgurl.bcground_2
        list[2]['album'] = that.data.bgurl.bcground_3
        list[3]['album'] = that.data.bgurl.bcground_4
        list[4]['album'] = that.data.bgurl.bcground_5
        list[5]['album'] = that.data.bgurl.bcground_6
        list[6]['album'] = that.data.bgurl.bcground_7
        list[7]['album'] = that.data.bgurl.bcground_8
        list[8]['album'] = that.data.bgurl.bcground_9
        that.setData({ 
          list: list
         })
        
         
      }
    })
  }
})