var app=getApp();
Page({

  data:{
    source: [
      {
        imgsrc: '../../images/1.jpg',
        content: '修改注册信息'
      }
    ]
  },

  

  bindViewTap:function(){
    wx.navigateTo({
      url: '../regist/regist?flag=1',
    })
  },

 onLoad:function(options){
   
 },
  getMyInfo:function(e){
    wx.login({
      success(res) {
        console.log(res)
        if (res.code) {
          //发起网络请求
          wx.request({
            url: 'https://test.com/onLogin',
            data: {
              code: res.code
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
    // console.log(e)
    let info = e.detail.userInfo;
    this.setData({
      isLogin: true,
      src: info.avatarUrl,
      nickName: info.nickName,
      province: info.province
    })
    console.log(e.detail.userInfo)
  }
})
/** 
   wxLogin: function(e) {
    var that = this; wx.login({
      success: function (res) {
        var code = res.code; //发送给服务器的code                 
        wx.getUserInfo({                    
          success: function(res) {                        
            var userNick = res.userInfo.nickName;                     
            var avataUrl = res.userInfo.avatarUrl;                                            var gender = res.userInfo.gender;                         
            console.log(avataUrl),                        
            that.setData({                            
              nick: userNick,                            
              avataUrl: avataUrl                        
              }) if (code) {                           
                wx.request({                                
                  url: 'http://你的域名/wxLogin.php',                                                data: {                                    
                    code: code,                                    
                    nick: userNick,                                    
                    avaurl: avataUrl,                                    
                    sex: gender,                                
                    },                                
                    header: {                                    
                      'content-type': 'application/json'                                },                                
                      success: function(res) {                                                              console.log(res.data);                                                            wx.setStorageSync('nick', res.data.nick);                                         wx.setStorageSync('openid', res.data.openid);                                    wx.setStorageSync('imgUrl', res.data.imgUrl);                                    wx.setStorageSync('sex', res.data.sex); }                
                       })                      
                         } else {                           
                            console.log("获取用户登录态失败！");                        }                    
}              
  })           
   },            
          fail: function(error) {                
            console.log('login failed ' + error);            }        })    }})
            */