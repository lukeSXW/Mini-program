var app = getApp();
Page({
  data: {
    list: {},
    inputVal:''
  },
  onLoad: function (options) {
    var that = this;
    var inputVal = options.inputVal;
    wx.request({
      url: 'http://apis.juhe.cn/cook/query?key=' + app.AppKey + '&menu=' + inputVal,
      method: 'GET',
      success: function (res) {
        console.log(res.data);
        var list = res.data.result.data;
        that.setData({ list: list })
      }
    })
    // 页面初始化 options为页面跳转所带来的参数
  }
})