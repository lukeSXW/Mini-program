// verity.js
// <!--
//   变量说明：
// windowHeight ：设备的窗口的高度
// windowWidth ： 设备的窗口的宽度
// idcard ： 身份证
// realname：真实姓名
// carid ：车号
// password: 密码
// subPassword ：确认密码
// -->
var util = require('../../utils/utils.js');  //常用方法
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    flag : 0,
    index: 0,
    array: ['无','肝病','胃病','脾病','消化不良','失眠','气血虚','高血压','糖尿病','高血脂','月经不调'],
    message: "注册",
    age : "",
    realname : "",
    idcard : ""
  },

  bindPickerChange: function (e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    
    this.setData({
      flag : options.flag
    })

    if(this.data.flag==1){
      this.setData({
        message : "修改注册信息"
      })
    }
    
    

    var app = getApp();
    var that = this;
    wx.getUserInfo({
      success: function (res) {
        var userInfo = res.userInfo;
        that.setData({
          userInfo: {
            avatar: userInfo.avatarUrl,
            nickname: userInfo.nickName
          }
        })
      }
    })
  },

  changifno: function (idcard, username, age) {
    console.log(idcard, username, age)
  },

  formSubmit: function (e) {
    // form 表单取值，格式 e.detail.value.name(name为input中自定义name值) ；使用条件：需通过<form bindsubmit="formSubmit">与<button formType="submit">一起使用  
    // var idcard = e.detail.value.idcard;
    // var realname = e.detail.value.realname;
      var that = this;
      var USERDISEASE = that.data.array[that.data.index];
      var IDcard = e.detail.value.idcard;
      var UserName = e.detail.value.realname;
      var Userage = e.detail.value.age;
      
      //changifno(IDcard, UserName, Userage)
      if (this.data.flag == 1) {
      wx.login({
        success(res){
          if(res.code){
            // console.log("这是更新时候的用户标识  " + res.code)
            wx.request({
              url: 'http://47.102.120.4:8080/account/updateuser',
              data: {
                username: res.code,
                disease: USERDISEASE,
              },
              
              header: {
                'content-type': "json",
                'charset': 'utf-8'
              },
              success: function (res) {
                wx.showToast({
                  title: '修改注册信息成功',
                }),
                  wx.switchTab({
                    url: '../index/index',
                  })
              },
            })
          }
        }
      })
      
    }
    else{
   wx.login({
     success(res){
       if(res.code){
        // console.log("这是注册时用户标识  "+res.code)
         wx.request({
           url: 'http://47.102.120.4:8080/account/user',
           data: {
             username: res.code,
             disease: USERDISEASE,
           },
           header: {
             'content-type': "json",
             'charset': 'utf-8'
           },
           success: function (res) {
             wx.showToast({
               title: '注册成功',
             }),
            wx.switchTab({
                 url: '../index/index',
              })
           },
         })
       }
     }
   })
    
    }
   },

   



 
  onReady: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },

 

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})