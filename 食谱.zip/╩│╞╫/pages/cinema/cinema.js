var app = getApp();
Page({
  data:{
    list_0: [],
    list_1: [],
    list_2: [],
    list_3: [],
    city:''
  },

  choosetp: function (e) {
    var that = this
    wx.chooseImage({
     count: 1,
     sizeType: ['original', 'compressed'],
     sourceType:['album','camera'],
     success(res) {
      const tempFilePaths = res.tempFilePaths
      that.setData({
        tempFilePaths : tempFilePaths
      })
      wx.uploadFile({
        url: 'http://47.102.120.4:8080/account/test',
        filePath: tempFilePaths[0],
        name: 'file',
        formData: {
        user: 'test'
     },
     
        success(res) {
          var jsonobj = JSON.parse(res.data)
          wx.navigateTo({
            url: '../searerror/searerror?jsonObj=' + encodeURIComponent(JSON.stringify(jsonobj))
          })  
        },
      }) 
  }  
   
    })
    },
  inputkey: function () {
    wx.navigateTo({
      url: '../../pages/search-1/search-1',
    })
  },
  navToDetail: function (e) {
    var id = e.currentTarget.id;
    wx.navigateTo({
      url: '/pages/detail/detail?id=' + id
    })
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    var that=this
    
    wx.getLocation({
      type: 'gcj02 ',
      success(res) {
        const latitude = res.latitude
        const longitude = res.longitude
        const speed = res.speed
        const accuracy = res.accuracy
        // console.log(res)
        wx.request({
          
          url: 'http://v.juhe.cn/weather/geo?format=2&key=19677d1be628e7bc12aa10d092f3dfff&lon=' + longitude + '&lat=' + latitude,
          success(res){
            
            var city = res.data.result.today.city
            that.setData({
                city:city
            }),
            // that.loadCity(longitude, latitude)
            wx.login({
              success(res){
                
            if(res.code){
              wx.request({
                url: 'http://47.102.120.4:8080/account/placetwo',
              data:{
                username:res.code,
                place: latitude+ ',' +longitude
              },
                success(res) {
                   var jsonobj_0 = JSON.parse(res.data[0])
                   var jsonobj_1 = JSON.parse(res.data[1])
                   var jsonobj_2 = JSON.parse(res.data[2])
                   var jsonobj_3 = JSON.parse(res.data[3])
                  that.setData({
                    list_0 : jsonobj_0.result.data,
                    list_1:  jsonobj_1.result.data,
                    list_2 : jsonobj_2.result.data,
                    list_3 : jsonobj_3.result.data,
                  })
                
                }
              })
              }
              }
            })
          }
        })
      }
    })
  },
  // loadCity: function (longitude, latitude) {
  //   var page = this
  //   wx.request({
  //     url: 'https://api.map.baidu.com/geocoder/v2/?ak=0a9d2d1b30b7e6255683fb9c5e17b336&location=' + latitude + ',' + longitude + '&output=json',
  //     header: {
  //       'Content-Type': 'application/json'
  //     },
  //     success: function (res) {
  //       console.log(res);
  //       var city = res.data.result.addressComponent.city;
  //       page.setData({ city: city });
  //     }
  //   })
  // },
  // bindKeyInput: function (e) {
  //   this.setData({
  //     inputVal: e.detail.value
  //   })
  // },
//   search: function (e) {
//     var page = this;
//     wx.request({
//       url: 'http://apis.juhe.cn/cook/query?key=' + app.AppKey + '&menu=' + page.data.inputVal,
//       data: {},
//       method: 'GET',
//       success: function (res) {
//         console.log(res.data);
//         var list = res.data.result.data;
//         page.setData({ list: list })
//       },
//       fail: function () {
//         // fail
//       },
//       complete: function () {
//         // complete
//       }
//     })
//   },
//   navToDetail: function (e) {
//     var id = e.currentTarget.id;
//     wx.navigateTo({
//       url: '/pages/detail/detail?id=' + id
//     })
//   }
})