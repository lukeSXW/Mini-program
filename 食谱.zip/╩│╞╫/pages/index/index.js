var util = require('../../utils/utils.js');
var app = getApp();
Page({
data:{
  lista: [], listb: [], listc: [], listd: [], liste: [], listf: [],
  list1:[],
  list2: [],
  list3: [],
  jname:'',
  jknow:'',
  TipsTitle:"节气知识卡片"
  },
  onLoad: function (e) {
   // 调用函数时，传入new Date()参数，返回值是日期和时间
    var time = util.formatTime(new Date());
    //再通过setData更改Page()里面的data，动态更新页面的数据
   
    this.setData({
      time: time,
    })
    var that=this;
    wx.request({
      url: 'http://47.102.120.4:8080/index?key=' + app.AppKey + '&cid=' + 10,
     success:function(res){
       var list = res.data.result.data;
       that.setData({ 
         list: list
        })
     }
    })
  },

  onLoad: function (res) {
    var that = this
    
    // 标题栏显示刷新图标，转圈圈
    wx.showNavigationBarLoading()
    // console.log("onPullDownRefresh");
    wx.request({
      url: 'http://47.102.120.4:8080/account/daily',
        success:function(res){
          var jsonObj = JSON.parse(res.data[0]);
          jsonObj = jsonObj.result.data
          jsonObj[0].albums[0] 
          ="https://i8.meishichina.com/attachment/recipe/2018/05/29/2018052915275310595262529722439.jpg?x-oss-process=style/p800"
          that.setData({
            list1: jsonObj
          })
          
          var jsonObj= JSON.parse(res.data[1]);
          
          jsonObj= jsonObj.result.data
          jsonObj[0].albums[0] = "https://i3.meishichina.com/attachment/recipe/2017/11/22/20171122151132012256513.jpg?x-oss-process=style/c320"
          that.setData({
            list2: jsonObj
          })
          

          var jsonObj = JSON.parse(res.data[2]);
          jsonObj = jsonObj.result.data
          jsonObj[0].albums[0] = "http://images.meishij.net/p/20110910/0bb73835fa4154532a983ae56b945a77.jpg"
          that.setData({
            list3: jsonObj
          })
     }
    })
    ,
    wx.request({
      url: 'http://47.102.120.4:8080/account/time',
      success(res){
        
        var jsonObj = JSON.parse(res.data.caiping[0]);
        jsonObj = jsonObj.result.data
        var jname = res.data.jieqi.jName
        var jknow = res.data.jieqi.jKnow
         that.setData({
              lista: jsonObj,
              jname: jname,
              jknow: jknow
         })

        
        var jsonObj = JSON.parse(res.data.caiping[1]);
        
        that.setData({
          listb: jsonObj.result.data
        })
        
        var jsonObj = JSON.parse(res.data.caiping[2]);
        
        that.setData({
          listc: jsonObj.result.data
        })
        var jsonObj = JSON.parse(res.data.caiping[3]);
        jsonObj = jsonObj.result.data
        jsonObj[0].albums[0] ="https://p.nanrenwo.net/uploads/allimg/180416/8477-1P416091133.png"
        that.setData({
          listd: jsonObj
        })
        
        var jsonObj = JSON.parse(res.data.caiping[4]);
        that.setData({
          liste: jsonObj.result.data
        })
      
        var jsonObj = JSON.parse(res.data.caiping[5]);
       
        that.setData({
          listf: jsonObj.result.data,
       
        })
      }
    }),

    
      

   // 请求最新数据
    // that.getData();

    setTimeout(() => {
      // 标题栏隐藏刷新转圈圈图标
      wx.hideNavigationBarLoading()

    }, 2000);

  },

  /**

   * 加载更多

   */

  onReachBottom: function () {
  // console.log('onReachBottom')
  },

  inputkey:function(){
    wx.navigateTo({
      url: '../../pages/search-1/search-1',
    })
  },
  navToDetail: function (e) {
    var id = e.currentTarget.id;
    wx.navigateTo({
      url: '/pages/detail/detail?id=' + id
    })
  }
})