//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
  }
,
  onShow: function () {
    console.log('App Show')
  },
  onHide: function () {
    console.log('App Hide')
  },
  gobalData: {
    hasLogin: false,
  },
  appData:{
    userinfo:null,
  },
  //聚合数据---菜谱的AppKey
  AppKey: 'c8ebc7f30032084b9d29e4b54bd4552b'
})
