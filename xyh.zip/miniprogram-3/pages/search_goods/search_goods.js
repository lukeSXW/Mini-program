// pages/search_goods/search_goods.js
let app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  add2car(e){
    let goodsId = e.target.id
    console.log(goodsId)
    wx.request({
      url: 'https://xiayuhui.top:8443/shopping/add',
      data:{
        goodsId,
        user:wx.getStorageSync('openid'),
        amount:1
      },
      success(res){
        wx.showToast({
          title: '加入购物车成功',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  search_goods(event) {
    let that = this
 
    if (event.detail.value.trim() != '') {
      wx.request({
        url: 'https://xiayuhui.top:8443/search/name',
        data: {
          name: event.detail.value.trim()
        },
        success(res) {
  
          if (res.data.length == 0) {
            wx.showModal({
              title: '找不到该商品哦！',
              showCancel:false
            })
          } else {
            that.setData({
              goods_arr: res.data
            })
          }
        }
      })
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})